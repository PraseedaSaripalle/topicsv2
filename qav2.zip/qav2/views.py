import json

from django.http import JsonResponse
from django.shortcuts import render
from .models import Question,Topic,Answer
'''
# Create your views here.



def autocomplete(request):
    if 'term' in request.GET:
        qs = Topic.objects.filter(title__icontains=request.GET.get('term'))
        titles = list()
        for product in qs:
            titles.append(product.title)
        # titles = [product.title for product in qs]
        return JsonResponse(titles, safe=False)
    return render(request, "topicssummary.html")


def topic(request):
    print("in home")
    return render(request,"topic.html")

def retireveTopic(request):
    print("inside retrieve topic")
    #topic=Topic.objects.all()
    topic=Topic.objects.filter(topic_level=1)
    print("My topics",topic)
    
    return render(request,'topic.html',{'topic':topic})
    '''

def retireveTopic(request):
    print("inside retrieve topic")
    #topic=Topic.objects.all()
    topics=Topic.objects.all()
    print("My topics",topics)
    return render(request,'topicssummary.html',{'topic':topics})

def topic(request):
    print("in topic section")
    topics=list()
    if 'term' in request.GET:
        print("inside topic if condition")
        qs=Topic.objects.filter(topic_name__istartswith=request.GET.get("term"))   
        print("json object in topic function. 1", qs)
        for topic in qs:
            topics.append(topic.topic_name)
            print("json object in topic function.2 ")
        return JsonResponse(topics, safe=False)
    return render(request,"topicssummary.html",{'topics':topics})

def retireveSubTopic(request,topic_name):
    print("inside retireveSubTopi")
    print("topic_name", topic_name)
    topic=Topic.objects.get(topic_name=topic_name)
    subtopics=topic.children.all()
    print("My subtopics",subtopics)
    topics=list()
    #print("json object in topic function. 1")
    for topic in subtopics:
        topics.append(topic.topic_name)
        print("json object in topic function.2 ", topics)
    return JsonResponse({'topics': list(topics.values())})
    #return render(request,"topicssummary.html",{'topics':topics})


def questionDetails(request, topic):
    print("Displaying the details of the subtopics and the questions.")
    #Retrieving the Subtopics for a given topic
    print("topic_name",topic)
    rquestions=Question.objects.filter(topics__topic_name=topic)
    #topics__topic_name__istartswith=topic
    #rquestions=Question.objects.all()
    #ranswer=Answer.objects.all().filter(question__question_text=rquestions)
    #print("answers",ranswers)
    print("questions for that topic",rquestions)
    questions=list()
    for question in rquestions:
        questions.append(question.question_text)
        print("inside rquestions for loop")
    return JsonResponse(questions, safe=False)
    #return render(request,'topic.html',{'questions':rquestions})
    