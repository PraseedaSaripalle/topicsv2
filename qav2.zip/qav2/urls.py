from django.urls import path
from . import views

urlpatterns = [
    path('', views.topic, name='topic'),
    #path('', views.topic, name='topic'),
    
    path('retirevetopic/', views.retireveTopic, name='retirevetopic'),
    path('tsubques/<topic_name>/', views.retireveSubTopic, name='tsubques'),
    path('questions/<topic_name>/',views.questionDetails,name='questions'),
]